import { Curso } from "./curso";

export class PrerequisitoCurso {
    idPrerequisitoCurso?: number;
    estadoPrerequisitoCurso?: boolean;
    nombrePrerequisitoCurso?: String;
    curso?: Curso
}
