import { DisenioCurriculares } from "./disenio-curriculares";

export class EvaluacionDiagnosticaCurriculares {
    idEvaluacionDiagnosticaCurricular?: number;
    tecnicaEvaluar?: string;
    instrumnetoEvaluar?: String;
    estadoEvaluacionDiagnostica?: Boolean;
    disenioCurricular?: DisenioCurriculares;
}
