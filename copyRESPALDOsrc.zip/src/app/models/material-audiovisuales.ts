import { Silabo } from "./silabo";

export class MaterialAudiovisuales {
    idMaterialAudiovisual?: number;
    descripcionMaterialAudiovisual?: string;
    estadoMaterialAudiovisual?: Boolean;
    silabo?: Silabo;
}
