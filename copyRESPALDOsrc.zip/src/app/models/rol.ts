export class Rol {
    idRol?: number;
    nombreRol?: string;
    estadoRolActivo?: boolean;
}
