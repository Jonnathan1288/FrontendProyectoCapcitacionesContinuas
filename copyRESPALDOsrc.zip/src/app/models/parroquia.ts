import { Canton } from './canton';

export class Parroquia {
  idParroquia?: number;
  parroquia?: string;
  canton?: Canton;
}
