import { Area } from './area';

export class Especialidad {
  idEspecialidad?: number;
  codigoEspecialidad?: string;
  nombreEspecialidad?: string;
  estadoEspecialidadActivo?: boolean;
  area?: Area;
}
