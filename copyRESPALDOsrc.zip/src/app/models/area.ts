export class Area {
  idArea?: number;
  codigoArea?: string;
  nombreArea?: string;
  estadoAreaActivo?: boolean;
  
}
