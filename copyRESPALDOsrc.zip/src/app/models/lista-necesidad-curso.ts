import { NececidadCurso } from "./nececidad-curso";

export class ListaNecesidadCurso {
    idListaNecesidadCursos?: number;
    detalleNececidadCurso?: string;
    estadoDetalleNecesidad?: boolean;
    necesidadCurso?: NececidadCurso;
}
