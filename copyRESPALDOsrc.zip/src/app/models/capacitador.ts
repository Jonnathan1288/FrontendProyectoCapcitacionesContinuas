import { Usuario } from "./usuario";

export class Capacitador {
    idCapacitador?: number;
    tituloCapacitador?: string;
    estadoActivoCapacitador?: boolean;
    tipoAbreviaturaTitulo?: string;
    usuario?: Usuario
}
