import { Curso } from './curso';

export class HorarioCurso {
  idHorarioCurso?: number;
  estadoHorarioCurso?: boolean;
  dias?: string;
  horaInicio?: string;
  horaFin?: string;

  // horaInicio?: Date;
  // horaFin?: Date;
}
