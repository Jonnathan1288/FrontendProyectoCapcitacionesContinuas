import { DisenioCurriculares } from "./disenio-curriculares";

export class EvaluacionFinalCurriculares {
    idEvaluacionFinal?: number;
    tecnicaFormativaFinal?: string;
    instrumnetoFormativaFinal?: String;
    estadoEvaluacionFinal?: Boolean;
    disenioCurricular?: DisenioCurriculares;
}
