
export class EstudianteFenix {
    identificacion?: string;
    nombre1?: string;
    nombre2?: string;
    apellido1?: string;
    apellido2?: string;
    fechaNacimiento?: Date;
    direccion?: string;
    correo?: string;
    telefono?: string;
    celular?: string;
    genero?: string;
    etnia?: string;
    nivelinstruccion?: string;
}
