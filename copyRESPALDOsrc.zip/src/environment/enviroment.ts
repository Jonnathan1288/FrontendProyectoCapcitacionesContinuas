export const environment = {
  // apiuri: 'http://capacitaciones-continuas-ista.us-east-1.elasticbeanstalk.com/api',
  // apiUriSecurity: 'http://capacitaciones-continuas-ista.us-east-1.elasticbeanstalk.com/auth',


  apiuri: 'http://localhost:8080/api',
  apiUriSecurity: 'http://localhost:8080/auth',
 
};
